const express = require('express');
const path = require('path');
const hbs = require('hbs');

const app = express();
app.use(express.static(__dirname));

const travelRouter = require('./app_server/routes/travel');

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

app.use('/travel', travelRouter);

const port = 3000;

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});