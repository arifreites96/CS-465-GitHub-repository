const express = require('express');
const path = require('path');

const app = express();

// Serve static files from "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Port
const port = 3000;

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});